"""Groq LLM client wrapper.

Centralizes every call to the AI provider so retry policy, timeouts, and
error handling live in one place instead of being duplicated per page.
"""
import time
from typing import List, Dict

import streamlit as st
from groq import Groq

from config import GROQ_API_KEY, MODEL_NAME, MAX_TOKENS, REQUEST_TIMEOUT

MAX_RETRIES = 3
BASE_BACKOFF_SECONDS = 1.5

# The Groq SDK is generated with the same tooling as the OpenAI SDK, so it
# exposes equivalent exception classes. We resolve them defensively so this
# module doesn't break across Groq SDK versions that may rename internals.
try:
    from groq import APIError, APIConnectionError, RateLimitError, APIStatusError

    _RETRYABLE_EXCEPTIONS = (RateLimitError, APIConnectionError, APIStatusError, APIError)
except ImportError:  # pragma: no cover - fallback for older/newer SDK layouts
    _RETRYABLE_EXCEPTIONS = (Exception,)


class LLMError(Exception):
    """Raised when the LLM call fails after all retries (safe to show to users)."""


@st.cache_resource(show_spinner=False)
def get_client() -> Groq:
    if not GROQ_API_KEY:
        raise LLMError(
            "GROQ_API_KEY is not set. Add it to a .env file (see .env.example) "
            "and restart the app."
        )
    return Groq(api_key=GROQ_API_KEY, timeout=REQUEST_TIMEOUT)


def chat_completion(
    messages: List[Dict[str, str]],
    temperature: float = 0.4,
    max_tokens: int = MAX_TOKENS,
    model: str = MODEL_NAME,
) -> str:
    """
    Calls the Groq chat completion endpoint with bounded retries and
    exponential backoff. Raises LLMError with a user-safe message on failure.
    """
    client = get_client()
    last_error: Exception | None = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            content = response.choices[0].message.content
            if not content or not content.strip():
                raise LLMError("The model returned an empty response.")
            return content.strip()

        except _RETRYABLE_EXCEPTIONS as exc:  # noqa: PERF203
            last_error = exc
            if attempt < MAX_RETRIES:
                time.sleep(BASE_BACKOFF_SECONDS * attempt)
        except Exception as exc:  # noqa: BLE001 - surface unexpected errors safely
            last_error = exc
            break

    raise LLMError(
        f"AI request failed after {MAX_RETRIES} attempt(s). "
        f"Check your internet connection and GROQ_API_KEY, then try again. "
        f"(Internal: {type(last_error).__name__}: {last_error})"
    )
