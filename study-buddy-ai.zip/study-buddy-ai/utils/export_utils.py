"""Export helpers for quizzes and flashcards (CSV / Anki TSV / JSON)."""
import csv
import io
import json
from typing import List, Dict, Any


def flashcards_to_csv(flashcards: List[Dict[str, str]]) -> bytes:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Term", "Definition", "Hint"])
    for card in flashcards:
        writer.writerow([card.get("term", ""), card.get("definition", ""), card.get("hint", "")])
    return buf.getvalue().encode("utf-8")


def flashcards_to_anki_tsv(flashcards: List[Dict[str, str]]) -> bytes:
    """Anki-importable tab-separated Front/Back format."""
    buf = io.StringIO()
    for card in flashcards:
        front = card.get("term", "").replace("\t", " ").replace("\n", " ")
        back = card.get("definition", "").replace("\t", " ").replace("\n", " ")
        buf.write(f"{front}\t{back}\n")
    return buf.getvalue().encode("utf-8")


def quiz_to_json_bytes(quiz: Dict[str, Any]) -> bytes:
    return json.dumps(quiz, indent=2).encode("utf-8")
